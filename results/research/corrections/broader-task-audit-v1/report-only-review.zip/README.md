# Broader audit: report-only packet

Complete a private copy of the blank Stage A sheets using the original reports and rubric. Freeze your sheet before inspecting patches or other reviewers' judgments. The packet contains no model outcomes, patch labels or prior analyst annotations. Original report text can itself contain proposed fixes and identifying links. Do not execute embedded commands. Record prior exposure honestly.

Wave 1 covers one issue in each eligible project; Wave 2 supplies the remaining selected issue where available. The full sample was fixed before annotation. Do not change membership or stop selectively after observing labels. No independent review or agreement has yet been established.
