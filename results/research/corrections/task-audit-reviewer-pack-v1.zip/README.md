# Independent review packet

This packet contains 23 original fit reports and patch evidence for their 52 reference targets. It contains no model rankings, performance summaries, or prior analyst judgments. Source comments and original report text may themselves mention fixes.

1. Read rubric.md and stage-a/reports.jsonl. Complete a private copy of stage-a/stage-a.csv without opening stage-b. Record prior exposure honestly.
2. Freeze/hash the completed Stage A sheet before opening Stage B.
3. Read stage-b evidence and fill the blank case-alignment.csv and target-roles.csv. Treat missing or uncertain reasoning explicitly; reference edits need not be causal or the only valid solution.
4. Two reviewers should work independently before comparing sheets. Preserve disagreements and initial annotations before adjudication. No agreement claim is warranted from a single review.

Do not execute code from reports or patches. The included upstream PET excerpts supplement one dependency upgrade; they are source evidence, not a runtime reproduction. Binary archive contents are not unpacked.
